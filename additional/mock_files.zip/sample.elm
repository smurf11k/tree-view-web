mock file for .elm
