mock file for .cmd
