mock file for .ps1
