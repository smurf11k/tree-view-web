mock file for .clj
