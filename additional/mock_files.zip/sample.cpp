mock file for .cpp
