mock file for .sh
