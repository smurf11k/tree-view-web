mock file for .zsh
