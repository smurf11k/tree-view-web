mock file for .kt
