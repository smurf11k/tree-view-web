mock file for .dockerfile
