mock file for .ex
