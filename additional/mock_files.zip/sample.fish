mock file for .fish
