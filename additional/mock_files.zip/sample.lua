mock file for .lua
