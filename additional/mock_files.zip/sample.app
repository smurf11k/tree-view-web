mock file for .app
