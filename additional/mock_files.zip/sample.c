mock file for .c
