mock file for .rb
