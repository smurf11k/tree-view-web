mock file for .pl
