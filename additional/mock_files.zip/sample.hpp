mock file for .hpp
