mock file for .rs
