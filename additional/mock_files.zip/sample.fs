mock file for .fs
