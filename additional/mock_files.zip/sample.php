mock file for .php
