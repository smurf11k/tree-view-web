mock file for .bash
