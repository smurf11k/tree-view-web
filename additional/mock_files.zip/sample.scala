mock file for .scala
