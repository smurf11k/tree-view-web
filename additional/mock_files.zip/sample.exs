mock file for .exs
