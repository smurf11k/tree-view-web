mock file for .tsx
