mock file for .sql
