mock file for .kts
