mock file for .cxx
