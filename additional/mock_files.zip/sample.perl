mock file for .perl
