mock file for .h
