mock file for .hxx
