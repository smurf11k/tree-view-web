mock file for .js
