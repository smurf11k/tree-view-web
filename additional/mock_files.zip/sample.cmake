mock file for .cmake
