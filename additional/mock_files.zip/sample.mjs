mock file for .mjs
