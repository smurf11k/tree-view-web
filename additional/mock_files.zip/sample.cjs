mock file for .cjs
