mock file for .mts
