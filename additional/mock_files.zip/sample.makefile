mock file for .makefile
