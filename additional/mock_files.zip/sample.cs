mock file for .cs
