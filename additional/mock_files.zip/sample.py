mock file for .py
