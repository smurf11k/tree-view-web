mock file for .cc
