mock file for .bat
