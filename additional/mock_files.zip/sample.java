mock file for .java
