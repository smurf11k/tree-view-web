mock file for .psm1
