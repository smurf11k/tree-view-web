mock file for .ts
