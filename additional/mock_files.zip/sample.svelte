mock file for .svelte
