mock file for .cts
