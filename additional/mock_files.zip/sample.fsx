mock file for .fsx
