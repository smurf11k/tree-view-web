mock file for .vue
