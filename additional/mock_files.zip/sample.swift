mock file for .swift
