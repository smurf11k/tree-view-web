mock file for .jsx
