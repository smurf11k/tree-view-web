mock file for .vb
