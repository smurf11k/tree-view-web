mock file for .go
